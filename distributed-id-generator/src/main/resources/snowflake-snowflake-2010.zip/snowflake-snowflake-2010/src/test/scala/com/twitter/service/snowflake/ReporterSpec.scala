package com.twitter.service.snowflake

import org.specs._
import com.twitter.service.snowflake.gen._

class ReporterSpec extends SpecificationWithJUnit {
//
//  "report" should {
//    "not raise an exception when scribe is down" in {
//      val reporter = new Reporter
//      reporter.report(new AuditLogEntry(1, "useragent", 1)) mustNot throwAn[java.lang.Exception]
//    }
//
//    "should buffer on exceptions" in {
//      val reporter = new Reporter
//      reporter.report(new AuditLogEntry(1, "useragent", 1))
//      reporter.queue.size mustEqual 1
//      true
//    }
//  }
}
