package com.twitter.service.snowflake

import org.specs._

class SnowflakeServerSpec extends SpecificationWithJUnit {
}
