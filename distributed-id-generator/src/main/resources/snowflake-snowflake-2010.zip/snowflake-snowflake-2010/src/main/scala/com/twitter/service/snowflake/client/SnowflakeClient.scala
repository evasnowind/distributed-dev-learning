/** Copyright 2010-2012 Twitter, Inc. */
package com.twitter.service.snowflake.client
import com.twitter.service.snowflake.gen.Snowflake

object SnowflakeClient extends ThriftClient[Snowflake.Client]

